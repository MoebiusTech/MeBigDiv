#include "onboard_MAH01.hpp"

typedef DC_Motor Motor_Class;

class Mecanum_Car
{
public:
    int Now_spd;
    Mecanum_Car(Motor_Class *_LF_Wheel, Motor_Class *_RF_Wheel, Motor_Class *_LR_Wheel, Motor_Class *_RR_Wheel)
    {
        this->LF_Wheel = _LF_Wheel;
        this->RF_Wheel = _RF_Wheel;
        this->LR_Wheel = _LR_Wheel;
        this->RR_Wheel = _RR_Wheel;
    }
    void Init(void)
    {
        LF_Wheel->Init(0); 
        RF_Wheel->Init(1); 
        LR_Wheel->Init(0); 
        RR_Wheel->Init(1); //初始化电机PWM
    }
    void runSpd(int Spd)
    {
        LF_Wheel->runSpd(Spd); 
        RF_Wheel->runSpd(Spd);
        LR_Wheel->runSpd(Spd); 
        RR_Wheel->runSpd(Spd);
    }
    void ROS_Move(float Line_vel,float Angle_vel);
    void PID_RunSpd(int Spd)
    {
        RR_Wheel_Spd = LF_Wheel_Spd = LR_Wheel_Spd = RF_Wheel_Spd = constrain(Spd, -MAX_RPM, MAX_RPM);  
    }
    void PID_ROS_Move(float Line_vel,float Angle_vel);
  void Increment_PID(void)
  {
    LF_Wheel->Incremental_PID(LF_Wheel_Spd);
    RF_Wheel->Incremental_PID(RF_Wheel_Spd);
    LR_Wheel->Incremental_PID(LR_Wheel_Spd);
    RR_Wheel->Incremental_PID(RR_Wheel_Spd);
  }
  void Update_PID(float _kp, float _ki, float _kd);
  
  int LR_Wheel_Spd;
  int RR_Wheel_Spd;
  int RF_Wheel_Spd;
  int LF_Wheel_Spd;
private:
  struct rt_device_pwm *pwm_dev;
    Motor_Class *LF_Wheel;
    Motor_Class *RF_Wheel;
    Motor_Class *LR_Wheel;
    Motor_Class *RR_Wheel;
};
